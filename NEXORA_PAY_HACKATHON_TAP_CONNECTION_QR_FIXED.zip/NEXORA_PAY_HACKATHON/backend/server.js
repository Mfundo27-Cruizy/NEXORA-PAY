import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import QRCode from 'qrcode';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import os from 'node:os';
import { createPublicClient, http, parseAbiItem, formatUnits, isAddress, getAddress } from 'viem';
import { baseSepolia } from 'viem/chains';
// x402 is optional during merchant-checkout startup. A mismatched SDK export must not crash TAP.
let paymentMiddleware=null, Network=null, Resource=null, x402LoadError=null;
try { ({ paymentMiddleware, Network, Resource } = await import('@coinbase/x402/express')); }
catch (error) { x402LoadError=error.message; console.warn('x402 machine endpoint disabled:', x402LoadError); }

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
const allowedOrigins=(process.env.CORS_ORIGIN||'').split(',').map(x=>x.trim()).filter(Boolean);
app.use(cors({origin:(origin,cb)=>{ if(!origin || allowedOrigins.length===0 || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) return cb(null,true); return cb(new Error('CORS blocked origin: '+origin)); }}));
app.use(express.json({limit:'100kb'}));
const PORT=Number(process.env.PORT||4242), CHAIN_ID=Number(process.env.CHAIN_ID||84532);
const lanIPv4=Object.values(os.networkInterfaces()).flat().find(x=>x && (x.family==='IPv4'||x.family===4) && !x.internal)?.address;
// Prefer an explicitly configured public/LAN URL. localhost is reliable for same-device tests.
const PUBLIC_BASE_URL=(process.env.PUBLIC_BASE_URL||'http://localhost:'+PORT).trim().replace(/\/$/,'');
const MIN_CONFIRMATIONS=Math.max(1,Number(process.env.MIN_CONFIRMATIONS||2));
const RPC_URL=process.env.RPC_URL||'https://sepolia.base.org';
const USDC=(process.env.USDC_CONTRACT||'0x036CbD53842c5426634e7929541eC2318f3dCF7e').toLowerCase();
const MERCHANT=(process.env.MERCHANT_WALLET||'').trim();
const TTL=Number(process.env.ORDER_TTL_SECONDS||60);
const FX_TTL=Number(process.env.FX_QUOTE_TTL_SECONDS||60);
const DB=path.join(__dirname,'data','orders.json');fs.mkdirSync(path.dirname(DB),{recursive:true});
const read=()=>{try{return JSON.parse(fs.readFileSync(DB,'utf8'))}catch{return {orders:[],refunds:[],lastBlock:0}}};
const write=db=>fs.writeFileSync(DB,JSON.stringify(db,null,2));
const configured=()=>isAddress(MERCHANT);
const client=createPublicClient({chain:baseSepolia,transport:http(RPC_URL,{timeout:15000})});
const transferEvent=parseAbiItem('event Transfer(address indexed from, address indexed to, uint256 value)');
const money6=n=>BigInt(Math.round(n*1e6));
const eip681=(amount)=>`ethereum:${USDC}@${CHAIN_ID}/transfer?address=${MERCHANT}&uint256=${amount}`;
const checkoutUrl=id=>(PUBLIC_BASE_URL||('http://localhost:'+PORT))+'/checkout/'+encodeURIComponent(id);
const safe=(n)=>Number(n).toFixed(6);
app.get('/api/health',async(_req,res)=>{let block=null,rpcOk=false,rpcError=null;try{block=Number(await client.getBlockNumber());rpcOk=true}catch(e){rpcError=e.shortMessage||e.message}res.json({ok:true,configured:configured(),rpcOk,rpcError,network:'base-sepolia',chainId:CHAIN_ID,merchantWallet:configured()?getAddress(MERCHANT):null,publicBaseUrl:PUBLIC_BASE_URL,qrReady:true,lanIPv4:lanIPv4||null,minConfirmations:MIN_CONFIRMATIONS,block,watcherRunning,watcherError,x402Available:Boolean(paymentMiddleware&&Network&&Resource),x402LoadError})});
app.get('/checkout/:id',(_req,res)=>res.type('html').send(`<!doctype html><html lang="en"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NEXORA TAP Checkout</title><style>body{font:16px system-ui;background:#f3f7fb;color:#102a43;margin:0;padding:20px}.box{max-width:480px;margin:4vh auto;background:white;border-radius:18px;padding:24px;box-shadow:0 8px 30px #102a4318}h1{margin:5px 0 12px}button{width:100%;padding:15px;border:0;border-radius:10px;background:#087f5b;color:white;font-weight:700;font-size:16px;margin-top:14px}button:disabled{opacity:.55}.muted{color:#627d98}.amount{font-size:30px;font-weight:800}.status{padding:12px;border-radius:9px;background:#edf6fa;margin-top:12px;word-break:break-word}.label{display:flex;justify-content:space-between;border-bottom:1px solid #e5edf3;padding:10px 0;gap:12px}.label b{text-align:right;overflow-wrap:anywhere}</style><div class="box"><div style="color:#087f9b;font-weight:800;letter-spacing:2px">NEXORA TAP</div><h1>Pay this merchant</h1><p class="muted">Base Sepolia testnet · Test USDC only</p><div id="details">Loading secure checkout…</div><button id="pay" disabled>Connect wallet &amp; pay</button><div id="status" class="status">Waiting for checkout details.</div><p class="muted" style="font-size:12px">Never enter a recovery phrase or private key. Confirm the token, amount and network in your wallet before approving.</p></div><script>
const orderId=decodeURIComponent(location.pathname.split('/').pop());const el=id=>document.getElementById(id);let order;
const pad=s=>String(s).replace(/^0x/,'').toLowerCase().padStart(64,'0');
async function load(){try{const r=await fetch('/api/orders/'+encodeURIComponent(orderId));const j=await r.json();if(!r.ok)throw new Error(j.error||'Checkout not found');order=j;const safeDesc=String(order.description).replace(/[&<>\"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]});el('details').innerHTML='<div class="amount">'+Number(order.usdcAmount).toFixed(6)+' USDC</div><div class="label"><span>Merchant sale</span><b>'+safeDesc+'</b></div><div class="label"><span>Order</span><b>'+order.id+'</b></div><div class="label"><span>Rand reference</span><b>R'+Number(order.zarAmount).toFixed(2)+'</b></div><div class="label"><span>Network</span><b>Base Sepolia</b></div><div class="label"><span>Recipient</span><b>'+order.merchantWallet+'</b></div><div class="label"><span>Expires</span><b>'+new Date(order.expiresAt).toLocaleTimeString()+'</b></div>';el('pay').disabled=order.status!=='PENDING'||Date.now()>Date.parse(order.expiresAt);el('status').textContent=order.status==='PENDING'?'Review the details, connect your wallet and approve the exact testnet payment.':'This checkout is '+order.status+'.';}catch(e){el('details').textContent=e.message;el('status').textContent='Unable to load checkout.'}}
el('pay').onclick=async function(){try{if(!window.ethereum)throw new Error('No compatible wallet found. Open this page in a browser with MetaMask or another injected EVM wallet.');el('pay').disabled=true;el('status').textContent='Connecting wallet…';const accounts=await window.ethereum.request({method:'eth_requestAccounts'});if(!accounts||!accounts.length)throw new Error('Wallet connection was not approved.');const wanted='0x14a34';const chain=await window.ethereum.request({method:'eth_chainId'});if(chain.toLowerCase()!==wanted){try{await window.ethereum.request({method:'wallet_switchEthereumChain',params:[{chainId:wanted}]})}catch(e){if(e.code===4902){await window.ethereum.request({method:'wallet_addEthereumChain',params:[{chainId:wanted,chainName:'Base Sepolia',nativeCurrency:{name:'Ether',symbol:'ETH',decimals:18},rpcUrls:['https://sepolia.base.org'],blockExplorerUrls:['https://sepolia.basescan.org']}]})}else throw e}}
const data='0xa9059cbb'+pad(order.merchantWallet)+pad(order.usdcRaw);el('status').textContent='Confirm the USDC transfer in your wallet…';const hash=await window.ethereum.request({method:'eth_sendTransaction',params:[{from:accounts[0],to:order.tokenContract,data:data,value:'0x0'}]});el('status').innerHTML='Transaction submitted: <a target="_blank" rel="noopener" href="https://sepolia.basescan.org/tx/'+hash+'">View on BaseScan ↗</a><br>Waiting for NEXORA to verify it…';let tries=0;const poll=setInterval(async function(){tries++;try{const r=await fetch('/api/orders/'+encodeURIComponent(orderId));const x=await r.json();if(x.status==='PAID'){el('status').textContent='Payment verified by NEXORA. You may return to the merchant.';clearInterval(poll)}else if(['EXPIRED','FAILED','UNDERPAID','OVERPAID','LATE_PAYMENT'].includes(x.status)){el('status').textContent='Payment status: '+x.status;clearInterval(poll)}else if(tries>90){el('status').textContent='Transaction submitted. Merchant verification is still pending; do not pay again. Transaction: '+hash;clearInterval(poll)}}catch(e){}},3000);
}catch(e){el('status').textContent=e.message;el('pay').disabled=false}};load();
</script></html>`));
app.get('/api/orders/:id',(req,res)=>{const o=read().orders.find(x=>x.id===req.params.id);if(!o)return res.status(404).json({error:'Checkout not found.'});res.json(o)});
app.post('/api/orders',async(req,res)=>{try{
 if(!configured())return res.status(503).json({error:'Set MERCHANT_WALLET in backend/.env to a valid Base Sepolia address first.'});
 const description=String(req.body.description||'').trim().slice(0,100),zar=Number(req.body.zarAmount),customerRef=String(req.body.customerRef||'').trim().slice(0,80);
 if(description.length<2||!Number.isFinite(zar)||zar<1||zar>1000000)return res.status(400).json({error:'Enter a description and a sale amount between R1 and R1,000,000.'});
 // Fetch a live ZAR/USD reference rate. Fail closed if unavailable: never silently use a stale/demo FX quote.
 const fxUrl=process.env.FX_API_URL||'https://open.er-api.com/v6/latest/ZAR';const fxRes=await fetch(fxUrl,{signal:AbortSignal.timeout(7000)});if(!fxRes.ok)throw new Error('Live FX provider unavailable; try again shortly.');const fx=await fxRes.json();const zarPerUsd=Number(fx?.rates?.USD);if(!(zarPerUsd>0))throw new Error('FX provider returned an invalid ZAR/USD rate.');
 const usd=zar*zarPerUsd;const cents=money6(usd);const db=read();
 // Add a deterministic-per-order 1–999 micro-USDC suffix so same-priced simultaneous sales are distinguishable.
 let suffix=BigInt(1+Math.floor(Math.random()*999));let raw=cents+suffix;while(db.orders.some(o=>o.usdcRaw===raw.toString())){suffix=suffix===999n?1n:suffix+1n;raw=cents+suffix;}const usdc=Number(formatUnits(raw,6));
 const now=Date.now(),id='NXT-'+now.toString(36).toUpperCase()+'-'+Math.random().toString(36).slice(2,7).toUpperCase();
 const order={id,description,customerRef,zarAmount:Number(zar.toFixed(2)),fxZarPerUsd:zarPerUsd,fxSource:fx.provider||'FX API',fxQuotedAt:new Date().toISOString(),usdcAmount:usdc,usdcRaw:raw.toString(),merchantWallet:getAddress(MERCHANT),tokenContract:getAddress(USDC),network:'Base Sepolia',chainId:CHAIN_ID,status:'PENDING',createdAt:new Date(now).toISOString(),fxExpiresAt:new Date(now+FX_TTL*1000).toISOString(),expiresAt:new Date(now+TTL*1000).toISOString(),txHash:null,payer:null,refundStatus:null};
 order.paymentUri=eip681(raw);order.checkoutUrl=checkoutUrl(id);order.qrDataUrl=await QRCode.toDataURL(order.checkoutUrl,{errorCorrectionLevel:'H',margin:3,width:420});db.orders.push(order);write(db);res.status(201).json(order);
 }catch(e){res.status(502).json({error:e.message||'Could not create checkout.'})}});
app.get('/api/orders',(_req,res)=>{const db=read();res.json({orders:db.orders.map(({usdcRaw,...o})=>o).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))})});
app.post('/api/orders/:id/refund', (req,res)=>{const db=read(),o=db.orders.find(x=>x.id===req.params.id);if(!o)return res.status(404).json({error:'Order not found.'});if(o.status!=='PAID')return res.status(409).json({error:'Only a confirmed paid order can be refunded.'});if(o.refundStatus)return res.status(409).json({error:'A refund request already exists.'});const addr=String(req.body.refundAddress||'');if(!isAddress(addr))return res.status(400).json({error:'A valid customer wallet address is required.'});const refund={id:'NXR-'+Date.now().toString(36).toUpperCase(),orderId:o.id,refundAddress:getAddress(addr),amount:o.usdcAmount,status:'AWAITING_MERCHANT_SIGNATURE',createdAt:new Date().toISOString(),note:'No funds sent. Merchant must independently verify the address and sign the USDC transfer.'};db.refunds.push(refund);o.refundStatus=refund.status;write(db);res.status(201).json({refundId:refund.id,status:refund.status,refundAddress:refund.refundAddress,amount:refund.amount,transferUri:`ethereum:${USDC}@${CHAIN_ID}/transfer?address=${refund.refundAddress}&uint256=${o.usdcRaw}`,warning:refund.note})});
app.get('/api/refunds',(_req,res)=>res.json({refunds:read().refunds}));
app.get('/api/unmatched-transfers',(_req,res)=>res.json({transfers:read().unmatchedTransfers||[]}));
// Machine-native x402: exact 0.01 USDC testnet charge for one weather-data response.
if(configured()){
 const price=`$${Number(process.env.MACHINE_PRICE_USDC||0.01).toFixed(2)}`;
 app.use(paymentMiddleware(getAddress(MERCHANT),{'/api/machine/weather':new Resource({price,network:Network.BaseSepolia})},{network:Network.BaseSepolia}));
}
app.get('/api/machine/weather',(_req,res)=>{if(!paymentMiddleware)return res.status(503).json({error:'x402 SDK is unavailable; merchant TAP checkout can still run.',details:x402LoadError});res.json({resource:'NEXORA agricultural weather sample',unit:'one request',data:{forecast:'Demo response payload',rainRisk:'moderate',temperatureC:23},paid:true,issuedAt:new Date().toISOString()})});
app.get('/api/machine/status',(_req,res)=>res.json({x402Enabled:Boolean(configured()&&paymentMiddleware),configured:configured(),sdkAvailable:Boolean(paymentMiddleware&&Network&&Resource),sdkError:x402LoadError,network:'Base Sepolia',priceUSDC:Number(process.env.MACHINE_PRICE_USDC||0.01)}));
let watcherRunning=false,watcherError=null;
async function scan(){
 if(!configured())return; watcherRunning=true;
 try{
  const db=read(),latest=await client.getBlockNumber();
  const from=db.lastBlock?BigInt(db.lastBlock+1):(latest>500n?latest-500n:0n),to=latest;
  if(from<=to){
   const logs=await client.getLogs({address:getAddress(USDC),event:transferEvent,args:{to:getAddress(MERCHANT)},fromBlock:from,toBlock:to});
   for(const log of logs){
    const tx=log.transactionHash;
    if(db.orders.some(o=>o.txHash===tx))continue;
    const raw=log.args.value.toString();
    const block=await client.getBlock({blockNumber:log.blockNumber});
    const paidAtMs=Number(block.timestamp)*1000;
    const order=db.orders.find(o=>['PENDING','EXPIRED'].includes(o.status)&&o.usdcRaw===raw&&paidAtMs>=Date.parse(o.createdAt));
    if(order){
     order.txHash=tx;order.payer=log.args.from;order.detectedAt=new Date().toISOString();
     order.blockNumber=Number(log.blockNumber);order.confirmations=Number(latest-log.blockNumber+1n);
     if(paidAtMs>Date.parse(order.fxExpiresAt||order.expiresAt)){order.status='LATE_PAYMENT';order.latePayment=true;}
     else order.status='VERIFYING';
    }else{
     db.unmatchedTransfers=db.unmatchedTransfers||[];
     db.unmatchedTransfers.push({txHash:tx,from:log.args.from,amountRaw:raw,blockNumber:Number(log.blockNumber),detectedAt:new Date().toISOString(),status:'UNMATCHED'});
    }
   }
   db.lastBlock=Number(to);
  }
  for(const o of db.orders){
   if(o.status==='VERIFYING'&&o.txHash){
    const receipt=await client.getTransactionReceipt({hash:o.txHash});
    if(receipt.status!=='success'){o.status='FAILED';o.failureReason='Transaction reverted';continue;}
    const latestNow=await client.getBlockNumber();o.confirmations=Number(latestNow-BigInt(o.blockNumber)+1n);
    if(o.confirmations>=MIN_CONFIRMATIONS){o.status='PAID';o.paidAt=new Date().toISOString();}
   }
   if(o.status==='PENDING'&&Date.now()>Date.parse(o.expiresAt))o.status='EXPIRED';
  }
  write(db);watcherError=null;
 }catch(e){watcherError=e.message;console.error('Watcher:',e.message)}finally{watcherRunning=false}
}
setInterval(scan,4000);scan();
app.listen(PORT,'0.0.0.0',()=>{console.log(`\nNEXORA TAP backend ready: http://localhost:${PORT}`);console.log(`Merchant wallet: ${configured()?'configured':'NOT CONFIGURED (set MERCHANT_WALLET in .env)'}`);console.log(`Checkout base URL: ${PUBLIC_BASE_URL}`);console.log(`RPC: ${RPC_URL}`);console.log(`x402: ${paymentMiddleware?'available':'disabled (merchant checkout remains available)'}`);console.log('Open http://localhost:'+PORT+'/api/health to diagnose connection.\n');});
