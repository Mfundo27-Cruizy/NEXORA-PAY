@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo        NEXORA TAP BACKEND STARTER
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not on PATH.
  echo Install Node.js 20 or newer, then reopen this window.
  pause
  exit /b 1
)
if not exist .env (
  copy .env.example .env >nul
  echo Created backend\.env from .env.example.
  echo IMPORTANT: Edit .env and replace MERCHANT_WALLET with your public Base Sepolia receiving address.
)
if not exist node_modules (
  echo Installing backend dependencies. This may take a few minutes...
  call npm install
  if errorlevel 1 (
    echo Dependency installation failed. Check your internet connection and Node.js version.
    pause
    exit /b 1
  )
)
echo Checking backend JavaScript...
call npm run check
if errorlevel 1 (
  echo Backend syntax check failed.
  pause
  exit /b 1
)
echo.
echo Starting NEXORA TAP at http://localhost:4242
 echo Open http://localhost:4242/api/health in your browser to confirm it is online.
echo Keep this window open while using NEXORA TAP.
echo.
call npm run dev
pause
