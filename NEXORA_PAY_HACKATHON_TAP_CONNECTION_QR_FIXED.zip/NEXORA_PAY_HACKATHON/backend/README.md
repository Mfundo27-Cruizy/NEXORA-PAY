# NEXORA TAP — Base Sepolia testnet payment backend

This adds a real testnet checkout path to the NEXORA browser demo. It uses USDC on Base Sepolia, a live ZAR/USD quote, an mobile checkout URL QR (the page connects to an injected wallet and submits the exact ERC-20 transfer), and a server-side Transfer-event watcher that matches the exact unique USDC amount to an unexpired order. It also exposes an x402-protected machine endpoint.

## Requirements
- Node.js 20+
- A dedicated Base Sepolia test wallet address controlled by the team (receiving address only)
- Test USDC on Base Sepolia for a customer wallet to pay; a little test ETH for wallets that need gas

## Setup (Windows — easiest)
1. Open `backend/start_backend.bat` by double-clicking it. The first run checks Node.js, copies `.env.example` to `.env`, installs dependencies, checks the server syntax and starts the API.
2. Edit `backend/.env` and replace `MERCHANT_WALLET` with your public Base Sepolia receiving address. Restart the backend after editing.
3. Open `http://localhost:4242/api/health`. It should return JSON with `ok: true`. Keep the terminal window open.

## Setup (manual)
1. Open a terminal in `backend/`.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set `MERCHANT_WALLET` to your dedicated Base Sepolia receiving address. Do not put a private key or seed phrase in this project.
5. Run `npm run dev`. The backend prints the local URL. By default, QR links use the first available LAN IPv4 address; the phone scanning the QR must be on the same Wi-Fi and able to reach the computer. For a remote phone, deploy the backend or set `PUBLIC_BASE_URL` to an HTTPS tunnel/deployed backend URL, then restart it. Do not use `localhost` in a QR intended for another device.
6. Serve `../nexora/` with a local web server (for example VS Code Live Server). Development CORS is open (`CORS_ORIGIN=*`) in the sample `.env`; restrict this before deployment. In NEXORA TAP, set the Payment backend URL to `http://localhost:4242` and click Save connection.
7. Open the QR checkout link on a phone with MetaMask or another EVM wallet browser/provider. If the phone's normal camera opens a browser without wallet support, open the checkout link inside the wallet's browser. Both payer and merchant must be on Base Sepolia; the payer needs test USDC and test ETH for gas.
8. FX rate quote is held for 60 seconds; the payment request expires after 60 seconds by default. Create a fresh checkout if the quote expires. The order expiry can be adjusted with `ORDER_TTL_SECONDS`.

## Troubleshooting backend offline / QR not generated
- Double-click `backend/start_backend.bat` on Windows and leave the terminal open.
- Visit `http://localhost:4242/api/health`. If this page does not load, the backend is not running or port 4242 is blocked/in use.
- If Node.js is missing, install Node.js 20 or newer and reopen the terminal.
- If dependency installation fails, check internet access, then run `npm install` again in `backend/`.
- If health says `configured:false`, edit `.env` and replace the placeholder `MERCHANT_WALLET` with a valid public Base Sepolia address.
- If `rpcOk:false`, the backend is running but the Base Sepolia RPC is unreachable; try again or configure another Base Sepolia RPC URL.
- If the checkout is created but the QR cannot be scanned by another phone, set `PUBLIC_BASE_URL` to the computer's LAN IP (for example `http://192.168.1.20:4242`) and ensure both devices are on the same Wi-Fi. Do not put `localhost` in a QR intended for another device.
- The x402 SDK is optional at startup. If its package/API is unavailable, merchant TAP still starts; `/api/machine/status` reports that x402 is disabled.

## Endpoints
- `GET /api/health` — network/backend readiness
- `POST /api/orders` — create a ZAR-priced order and locked USDC quote (quote/order validity is 60 seconds by default)
- `GET /api/orders` — merchant order list/status
- `GET /api/orders/:id` — public checkout details/status for one order (includes the exact test token amount)
- `GET /checkout/:id` — mobile checkout page opened by the QR code
- `POST /api/orders/:id/refund` — records a refund request; DOES NOT send funds
- `GET /api/refunds` — refund queue
- `GET /api/machine/weather` — x402 exact-payment resource (0.01 test USDC)
- `GET /api/machine/status` — x402 readiness

## Important implementation notes
- Chain: Base Sepolia (chain ID 84532); USDC contract: `0x036CbD53842c5426634e7929541eC2318f3dCF7e`. Confirm this against Circle/Base documentation before demos.
- The backend uses exact-amount matching with a micro-USDC suffix and checks for duplicate amounts among stored orders. The QR encodes a mobile checkout URL, not a raw wallet URI: the customer opens the page in a wallet-enabled browser, reviews the amount/recipient/network, and signs the ERC-20 transfer. This is still a hackathon matching method, not a substitute for unique deposit addresses or a payment contract at production scale.
- The watcher scans recent blocks on startup and then polls every four seconds. It waits for the configured confirmation threshold (2 by default) before setting PAID, records unmatched incoming transfers, and flags matching transfers mined after the order expiry as LATE_PAYMENT. For production use a managed RPC/websocket/indexer, persistent database, reorg handling, finality policy, idempotent event store and monitoring. The demo stores records in `data/orders.json`.
- FX comes from the configured external FX API when an order is created. The displayed quote and expiry are stored with the order. It is a reference rate, not a guaranteed executable conversion or off-ramp quote.
- `PAID` means the backend observed a successful exact USDC Transfer event and the configured confirmation threshold was met. This is not a full chain-reorg/finality service. Unmatched transfers are retained in the local data file for operator review; matching late payments are flagged as LATE_PAYMENT and are not marked PAID. Under/overpayments still require manual reconciliation.
- Refunds are deliberately manual: the API creates an auditable refund request and EIP-681 return-transfer URI. A merchant must inspect the address and sign the transfer in its wallet. There are no chargebacks and no automatic reversal.
- x402 uses the Coinbase x402 Express middleware for the machine endpoint. Confirm the installed SDK version/API against the official x402 documentation when upgrading.
- This is TESTNET software only. Never point it at mainnet or real customer funds. It is not a licensed payment service, not a bank integration, and does not cash out to ZAR. Mainnet requires security review, compliance/legal review, secure operational controls, merchant onboarding, provider contracts and an appropriate off-ramp.

## Sponsor checklist mapping
- Rand price + stablecoin quote: yes, live reference FX API and stored quote.
- QR payment request: yes, EIP-681 QR. NFC can store the same checkout URL/URI; NFC hardware is not included.
- Customer wallet approval: wallet opens and signs the token transfer.
- Automatic matching: exact token contract, merchant recipient and unique amount matched by watcher.
- Merchant PAID status: yes, refreshes from backend; current demo polls manually/when opening TAP.
- Cash-out: not integrated; settlement/off-ramp remains a clearly labelled future/provider integration.
- Refunds: request and manual wallet-signing workflow; outgoing transfer is not automated.
- Machine payments: x402 endpoint included; needs merchant wallet configured and funded payer test wallet.
- Machine budgets/revocation: not yet on-chain; NEXORA PAY policy engine is a demo policy foundation. A production machine wallet needs enforceable smart-account/session-key limits and revocation.
