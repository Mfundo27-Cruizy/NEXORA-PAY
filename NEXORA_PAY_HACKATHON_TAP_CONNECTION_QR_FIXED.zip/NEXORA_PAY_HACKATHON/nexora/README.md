# NEXORA PAY — Version 3 (with NEXORA TRUST)

Open `index.html` in a modern browser (Chrome or Edge). Keep the `assets/` folder beside it.

## Modules
- NEXORA AI: local assistant with optional Anthropic API connection.
- NEXORA PAY: local demo payments, approvals, limits, protected reserve and CSV export.
- NEXORA GLOBAL: FX converter and international supplier payment preparation (demo only).
- NEXORA FLOW: 30-day cash forecast and what-if sales adjustment.
- NEXORA BUSINESS: invoices, expenses and inventory.
- NEXORA GUARD: payment risk checks and spending controls.
- NEXORA TRUST: SHA-256 hash-linked proof ledger for payment request/approval/rejection events, integrity verification and JSON export.

## NEXORA TRUST — important distinction
This version adds a **local cryptographic proof-chain prototype**. It hashes selected business event summaries with SHA-256 and links each record to the previous hash. You can verify the chain and export its records from the NEXORA TRUST screen.

This is **not yet a distributed or public blockchain integration**. Records are stored in this browser's localStorage and can be lost if browser data is cleared. The demo does not publish transactions to Ethereum, Polygon, Hyperledger or any other network, and it does not prove that a real payment or physical delivery occurred. A production blockchain connection requires a backend service, network choice, deployed smart contract (if needed), secure signing/key management, and appropriate privacy and compliance design.

## Demo limitations
- Demo data is stored in browser localStorage.
- No bank, payment network, live FX feed or public blockchain is connected.
- No real money moves.
- The optional AI key is stored in browser localStorage; use only for a prototype, not production.
- For production, move secrets and AI calls to a backend, use secure authentication/database storage, licensed payment partners, and appropriate KYC/AML and regulatory controls.


## V3 update — NEXORA TRUST and assistant improvements

- NEXORA TRUST proof ledger exports as a readable `.txt` file.
- The built-in local assistant has expanded workspace Q&A for balances, payment history, suppliers, invoices, expenses, inventory, cash flow, Guard alerts, currency conversion and NEXORA TRUST.
- The NEXORA FLOW advice action opens the NEXORA AI chat and sends the current forecast context there, so follow-up questions can be asked in the same chat.
- Save business rules button is green; Remove buttons are red; Export CSV button is light blue.
- The local assistant is a deterministic demo assistant, not a general-purpose LLM. Open-ended reasoning requires configuring a live AI provider.
- NEXORA TRUST remains a local SHA-256 proof chain stored in browser localStorage. It is not yet a distributed blockchain and does not verify real-world payment or delivery events.

## V3 update — invoice urgency, expense totals, PDF ledger and crypto requests

- Unpaid invoices with a due date more than one day away display in orange. Invoices due today, overdue, or due within one day display in red.
- Expenses now show a total of all recorded expense entries below the expense list.
- NEXORA TRUST now creates a formatted, color-styled print report. Choose **Download ledger PDF**, then select **Save as PDF** in the browser print dialog. Allow pop-ups for the report window.
- NEXORA GLOBAL includes a crypto payment-request prototype for USDC, USDT, BTC and ETH. It stores a local draft request and adds a proof event to NEXORA TRUST.
- Crypto requests are **not sent**. This prototype does not connect to a wallet, exchange, custody provider or blockchain network, and it does not quote live crypto prices. A real crypto payment feature requires secure wallet/key handling, network selection, address validation, transaction signing, compliance controls and suitable regulated partners where required.

## V3 update — NEXORA PAYROLL

- Added an employee payroll workspace under **NEXORA PAY**.
- Owners can add employees with a name, job title and individual pay amount.
- Payroll can be prepared using each employee's saved individual amount, or by entering one shared amount for every employee.
- Payroll runs support one-time, weekly, fortnightly and monthly schedule selections.
- Each employee payment is created as a separate pending approval in NEXORA PAY's payment activity. The owner approves or rejects each payment; approvals re-check the existing demo balance, daily spending cap and protected reserve.
- Payroll preparation events are added to the local NEXORA TRUST proof chain.
- Recurring frequency selections are saved as a schedule plan/reminder only. Because this is a browser-only localStorage demo, it cannot run a background scheduler, initiate real bank transfers or automatically pay employees on a future date. A production payroll automation service needs a secure backend scheduler, employee consent and verified payout details, payroll/tax calculations, permissions, audit controls and a regulated payment provider.
- All payroll values and approvals in this prototype are simulated. No employee bank account is accessed and no real money moves.

## V3 update — NEXORA PAYROLL tax desk (estimate prototype)

- Employee profiles now include a per-pay-run PAYE withholding input and an optional masked tax-reference field.
- Payroll preparation shows gross pay, PAYE withholding, employee UIF estimate and net pay. Each employee's payment request is for the estimated net amount, not gross salary.
- The payroll tax desk exposes configurable tax period/year, employee and employer UIF rates, monthly UIF earnings ceiling, SDL rate and annual payroll threshold.
- The tax desk estimates employer UIF, SDL and total employer payroll cost, and stores its settings in this browser.
- These are configurable planning estimates, not an official South African payroll/tax calculator. PAYE is entered per employee from a separately verified payroll calculation; this version does not implement SARS tax brackets, rebates, medical credits, fringe-benefit rules, employee-specific tax treatment, EMP201/IRP5 generation, UIF declarations or SARS eFiling. UIF/SDL assumptions must be verified for the relevant tax year and employer circumstances with SARS or a qualified payroll professional before use.
- No statutory return is filed and no tax is remitted. All payroll payments remain demo requests requiring owner approval; no real money moves.
