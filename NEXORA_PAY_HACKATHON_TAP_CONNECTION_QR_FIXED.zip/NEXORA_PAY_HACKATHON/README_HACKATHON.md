# NEXORA PAY — Hackathon build (TAP fixes)

This package preserves the NEXORA business platform and includes a corrected NEXORA TAP checkout flow. Start with `backend/README.md`.

## Key TAP fixes
- QR codes now encode a dedicated mobile checkout URL instead of a raw EIP-681 token URI.
- Checkout page displays the order, amount, merchant recipient and network, then connects to an injected EVM wallet and submits the exact USDC transfer.
- Backend URL can be configured in the NEXORA TAP screen.
- Backend health reports RPC readiness, QR URL readiness and watcher errors.
- QR URL defaults to the detected LAN IPv4 address; set `PUBLIC_BASE_URL` for HTTPS/public access.
- FX quote lock defaults to 60 seconds while payment request validity defaults to 10 minutes.
- Backend waits for 2 confirmations before marking an order PAID, flags matching late payments, and records unmatched transfers.

## Important
The QR can only be scanned by another device if its encoded URL is reachable from that device. For same-Wi-Fi testing, allow the backend port through the computer firewall and use the detected LAN IP. For remote use, deploy the backend or use an HTTPS tunnel and set `PUBLIC_BASE_URL`. Test only with Base Sepolia USDC. This remains hackathon testnet software, not a production payment service.
